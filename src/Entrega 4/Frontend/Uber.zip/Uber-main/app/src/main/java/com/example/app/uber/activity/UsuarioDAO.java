package com.example.app.uber.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.app.uber.activity.Usuario;

import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "appuber.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_USUARIO = "usuario";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_NOME = "nome";
    private static final String COLUMN_EMAIL = "email";

    public UsuarioDAO(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE_USUARIO + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_NOME + " TEXT NOT NULL," +
                COLUMN_EMAIL + " TEXT NOT NULL)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        String sql = "DROP TABLE IF EXISTS " + TABLE_USUARIO;
        db.execSQL(sql);
        onCreate(db);
    }

    public long inserir(Usuario usuario) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOME, usuario.getNome());
        values.put(COLUMN_EMAIL, usuario.getEmail());
        long id = db.insert(TABLE_USUARIO, null, values);
        db.close();
        return id;
    }

    public int atualizar(Usuario usuario) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_NOME, usuario.getNome());
        values.put(COLUMN_EMAIL, usuario.getEmail());
        int linhas = db.update(TABLE_USUARIO, values, COLUMN_ID + "=?", new String[]{String.valueOf(usuario.getId())});
        db.close();
        return linhas;
    }

    public int deletar(int id) {
        SQLiteDatabase db = getWritableDatabase();
        int linhas = db.delete(TABLE_USUARIO, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
        return linhas;
    }

    public List<Usuario> listarTodos() {
        List<Usuario> usuarios = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String sql = "SELECT * FROM " + TABLE_USUARIO + " ORDER BY " + COLUMN_NOME;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            do {
                Usuario u = new Usuario();
                u.setId(cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)));
                u.setNome(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOME)));
                u.setEmail(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMAIL)));
                usuarios.add(u);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return usuarios;
    }
}


