package com.example.app.uber.activity;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.example.app.uber.databinding.ActivityMainBinding;
import com.example.app.uber.firebase.FireBase;
import com.example.app.uber.helper.UsuarioFirebase;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private final String permissaoLocalizacao = Manifest.permission.ACCESS_FINE_LOCATION;
    private final String permissaoAudio = Manifest.permission.RECORD_AUDIO;
    private final String permissaoChamada = Manifest.permission.CALL_PHONE;

    private ActivityMainBinding binding;
    private Button buttonEntrar;
    private Button buttonCadastrar;
    private FirebaseAuth auth;

    private static final int REQUEST_CODE_PERMISSOES = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        buttonEntrar = binding.buttonEntrar;
        buttonCadastrar = binding.buttonCadastrar;

        Objects.requireNonNull(getSupportActionBar()).hide();

        verificarPermissoes();

        auth = FireBase.getFirebaseAuth();

        buttonEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        buttonCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CadastroActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

    }

    private void verificarPermissoes() {
        List<String> permissoesPendentes = new ArrayList<>();

        if (ActivityCompat.checkSelfPermission(this, permissaoLocalizacao) != PackageManager.PERMISSION_GRANTED) {
            permissoesPendentes.add(permissaoLocalizacao);
        }
        if (ActivityCompat.checkSelfPermission(this, permissaoAudio) != PackageManager.PERMISSION_GRANTED) {
            permissoesPendentes.add(permissaoAudio);
        }
        if (ActivityCompat.checkSelfPermission(this, permissaoChamada) != PackageManager.PERMISSION_GRANTED) {
            permissoesPendentes.add(permissaoChamada);
        }

        if (!permissoesPendentes.isEmpty()) {
            ActivityCompat.requestPermissions(this,
                    permissoesPendentes.toArray(new String[0]),
                    REQUEST_CODE_PERMISSOES);
        } else {
            iniciarServicoVoz();
        }
    }

    private void iniciarServicoVoz() {
        Intent serviceIntent = new Intent(this, ServicoVoz.class);
        startForegroundService(serviceIntent);
    }

    @Override
    protected void onStart() {
        super.onStart();
        UsuarioFirebase.redirecionaUsuarioLogado(MainActivity.this);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_CODE_PERMISSOES) {
            boolean todasConcedidas = true;
            for (int result : grantResults) {
                if (result == PackageManager.PERMISSION_DENIED) {
                    todasConcedidas = false;
                    break;
                }
            }

            if (todasConcedidas) {
                iniciarServicoVoz();
            } else {
                alertaValidacaoPermicao();
            }
        }
    }

    private void alertaValidacaoPermicao() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Permissão negada");
        builder.setMessage("Para utilizar o app é necessário aceitar as permissões solicitadas.");
        builder.setCancelable(false);
        builder.setPositiveButton("Confirmar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}
