package com.example.app.uber.helper;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.app.uber.activity.PassageiroActivity;
import com.example.app.uber.activity.RequisicoesActivity;
import com.example.app.uber.firebase.FireBase;
import com.example.app.uber.model.Usuario;
import com.firebase.geofire.GeoFire;
import com.firebase.geofire.GeoLocation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;

public class UsuarioFirebase {

    // Método para obter o usuário logado no Firebase
    private static FirebaseUser getUsuarioAtual() {
        return FireBase.getFirebaseAuth().getCurrentUser();
    }

    // Método para obter os dados do usuário logado
    public static Usuario getDadosUsuarioLogado() {
        FirebaseUser user = getUsuarioAtual();
        Usuario usuario = new Usuario();
        if (user != null) {
            usuario.setId(user.getUid());
            usuario.setEmail(user.getEmail());
            usuario.setNome(user.getDisplayName());
        }
        return usuario;
    }

    // Método para atualizar o nome do usuário no Firebase
    public static void atualizarNomeUsuario(String nome) {
        try {
            FirebaseUser user = getUsuarioAtual();
            if (user != null) {
                UserProfileChangeRequest profile = new UserProfileChangeRequest.Builder()
                        .setDisplayName(nome)
                        .build();
                user.updateProfile(profile).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (!task.isSuccessful()) {
                            Log.d("Perfil", "Erro ao atualizar perfil.");
                        }
                    }
                });
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método para redirecionar o usuário logado para a tela apropriada
    public static void redirecionaUsuarioLogado(Activity activity) {
        FirebaseUser user = getUsuarioAtual();
        if (user != null) {
            DatabaseReference usuariosRef = FireBase.getFirebaseDatabase()
                    .child("usuarios")
                    .child(getUidUsuario());

            usuariosRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    try {
                        Usuario usuario = snapshot.getValue(Usuario.class);
                        if (usuario != null) {
                            String tipoUsuario = usuario.getTipo();
                            Intent i;
                            if (tipoUsuario.equals("M")) {
                                i = new Intent(activity, RequisicoesActivity.class);
                            } else {
                                i = new Intent(activity, PassageiroActivity.class);
                            }
                            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                                    Intent.FLAG_ACTIVITY_NEW_TASK);
                            activity.startActivity(i);
                            activity.finish();
                        } else {
                            Log.e("UsuarioFirebase", "Usuário não encontrado no banco de dados.");
                        }
                    } catch (Exception e) {
                        Log.e("UsuarioFirebase", "Erro ao processar dados do usuário: " + e.getMessage());
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {
                    Log.e("UsuarioFirebase", "Erro no Firebase: " + error.getMessage());
                }
            });
        } else {
            Log.e("UsuarioFirebase", "Usuário não está logado.");
        }
    }

    // Método para obter o UID do usuário logado
    public static String getUidUsuario() {
        FirebaseUser user = getUsuarioAtual();
        return user != null ? user.getUid() : null;
    }

    // Método para atualizar a localização do usuário logado no Firebase
    public static void atualizarDadosLocalizacao(double lat, double lon) {
        // Define nó de local de usuário
        DatabaseReference loclaUsuario = FireBase.getFirebaseDatabase().child("local_usuario");
        GeoFire geoFire = new GeoFire(loclaUsuario);

        // Recuperar dados do usuário logado
        Usuario usuarioLogado = UsuarioFirebase.getDadosUsuarioLogado();
        if (usuarioLogado != null) {
            geoFire.setLocation(
                    usuarioLogado.getId(),
                    new GeoLocation(lat, lon),
                    new GeoFire.CompletionListener() {
                        @Override
                        public void onComplete(String key, DatabaseError error) {
                            if (error != null) {
                                Log.d("Erro", "Erro ao salvar o local!");
                            }
                        }
                    });
        }
    }
}
