package com.example.app.uber.activity;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;

import java.io.IOException;

public class ServicoVoz extends Service implements RecognitionListener {

    private static final String CHANNEL_ID = "voz_channel_id";
    private SpeechService speechService;

    @Override
    public void onCreate() {
        super.onCreate();
        criarCanalNotificacao();
    }

    private void criarCanalNotificacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    "Canal de Voz",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Monitorando segurança")
                .setContentText("Detectando emergência...")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .build();

        startForeground(1, notification);
    }

    private void copyAssetFolder(android.content.res.AssetManager assetManager, String fromAssetPath, String toPath) {
        try {
            String[] files = assetManager.list(fromAssetPath);
            if (files == null || files.length == 0) {
                // É arquivo, copia ele
                copyAssetFile(assetManager, fromAssetPath, toPath);
            } else {
                // É diretório, cria e copia arquivos/pastas dentro
                java.io.File dir = new java.io.File(toPath);
                if (!dir.exists()) dir.mkdirs();
                for (String file : files) {
                    copyAssetFolder(assetManager, fromAssetPath + "/" + file, toPath + "/" + file);
                }
            }
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }

    private void copyAssetFile(android.content.res.AssetManager assetManager, String assetPath, String outPath) {
        java.io.InputStream in = null;
        java.io.OutputStream out = null;
        try {
            in = assetManager.open(assetPath);
            java.io.File outFile = new java.io.File(outPath);
            out = new java.io.FileOutputStream(outFile);

            byte[] buffer = new byte[1024];
            int read;
            while ((read = in.read(buffer)) != -1) {
                out.write(buffer, 0, read);
            }
            out.flush();
        } catch (java.io.IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (in != null) in.close();
                if (out != null) out.close();
            } catch (java.io.IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            String modelPath = new java.io.File(getFilesDir(), "model").getAbsolutePath();

            // Copia a pasta 'model' do assets para armazenamento interno
            copyAssetFolder(getAssets(), "model", modelPath);

            // Cria o modelo com o caminho local
            Model model = new Model(modelPath);
            Recognizer recognizer = new Recognizer(model, 16000.0f);
            speechService = new SpeechService(recognizer, 16000.0f);
            speechService.startListening(this);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return START_STICKY;
    }

    @Override
    public void onPartialResult(String hypothesis) {
        Log.d("VOSK", "Parcial: " + hypothesis);
        if (hypothesis.toLowerCase().contains("socorro")) {
            ligarParaPolicia();
        }
    }

    @Override
    public void onResult(String hypothesis) {
        Log.d("VOSK", "Resultado: " + hypothesis);
    }

    @Override
    public void onFinalResult(String hypothesis) {
        Log.d("VOSK", "Final: " + hypothesis);
    }

    @Override
    public void onError(Exception e) {
        Log.e("VOSK", "Erro: ", e);
    }

    @Override
    public void onTimeout() {
        Log.d("VOSK", "Timeout");
    }

    private void ligarParaPolicia() {
        if (speechService != null) {
            speechService.stop();
        }

        Intent intent = new Intent(Intent.ACTION_CALL);
        intent.setData(android.net.Uri.parse("tel:190"));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (speechService != null) {
            speechService.stop();
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}

