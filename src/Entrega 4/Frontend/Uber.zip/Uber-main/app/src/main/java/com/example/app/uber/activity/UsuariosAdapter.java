package com.example.app.uber.activity;



import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.app.uber.R;
import com.example.app.uber.model.Usuario;

import java.util.List;

public class UsuariosAdapter extends RecyclerView.Adapter<UsuariosAdapter.UsuarioViewHolder> {

    public interface OnItemClickListener {
        void onItemClick(Usuario usuario);
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(Usuario usuario);
    }

    private List<Usuario> listaUsuarios;
    private OnItemClickListener clickListener;
    private OnItemLongClickListener longClickListener;

    public UsuariosAdapter(List<Usuario> lista, OnItemClickListener clickListener, OnItemLongClickListener longClickListener) {
        this.listaUsuarios = lista;
        this.clickListener = clickListener;
        this.longClickListener = longClickListener;
    }

    public void atualizarLista(List<Usuario> novaLista) {
        listaUsuarios = novaLista;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public UsuarioViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_usuario, parent, false);
        return new UsuarioViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull UsuarioViewHolder holder, int position) {
        Usuario usuario = listaUsuarios.get(position);
        holder.tvNome.setText(usuario.getNome());
        holder.tvEmail.setText(usuario.getEmail());

        holder.itemView.setOnClickListener(v -> {
            if (clickListener != null) clickListener.onItemClick(usuario);
        });

        holder.itemView.setOnLongClickListener(v -> {
            if (longClickListener != null) {
                longClickListener.onItemLongClick(usuario);
                return true;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return listaUsuarios.size();
    }

    static class UsuarioViewHolder extends RecyclerView.ViewHolder {
        TextView tvNome, tvEmail;

        public UsuarioViewHolder(@NonNull View itemView) {
            super(itemView);
           // tvNome = itemView.findViewById(R.id.tvNome);
          //  tvEmail = itemView.findViewById(R.id.tvEmail);
        }
    }
}

