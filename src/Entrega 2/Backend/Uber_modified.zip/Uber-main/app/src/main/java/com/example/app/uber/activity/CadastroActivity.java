package com.example.app.uber.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.app.uber.databinding.ActivityCadastroBinding;
import com.example.app.uber.firebase.FireBase;
import com.example.app.uber.helper.UsuarioFirebase;
import com.example.app.uber.model.Usuario;
import com.example.app.uber.utils.ValidationUtils;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.auth.FirebaseAuthWeakPasswordException;

import java.util.Objects;

public class CadastroActivity extends AppCompatActivity {

    private ActivityCadastroBinding binding;
    private TextInputEditText nome;
    private TextInputEditText email;
    private TextInputEditText confirmEmail;
    private TextInputEditText senha;
    private TextInputEditText confirmPassword;
    private Button buttonCadastrar;
    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private Switch switchCadastro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCadastroBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Associa os campos do layout às variáveis
        nome = binding.editCadastroNome;
        email = binding.editCadastroEmail;
        confirmEmail = binding.editTextConfirmEmail;
        senha = binding.editCadastroSenha;
        confirmPassword = binding.editTextConfirmPassword;
        buttonCadastrar = binding.btnCadastrar;
        switchCadastro = binding.switchCadastro;

        // Mostra botão de voltar na ActionBar
        Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);

        // Ação ao clicar no botão de cadastro
        buttonCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarCadastro(); // Chama método para validar e cadastrar
            }
        });
    }

    // Valida os dados do formulário de cadastro
    private void validarCadastro() {
        String nomeCad = nome.getText().toString();
        String emailCad = email.getText().toString();
        String confirmEmailCad = confirmEmail.getText().toString();
        String senhaCad = senha.getText().toString();
        String confirmPasswordCad = confirmPassword.getText().toString();

        // Verificações dos campos
        if (nomeCad.isEmpty()) {
            Toast.makeText(this, "Preencha seu nome completo", Toast.LENGTH_SHORT).show();
            return;
        }

        if (emailCad.isEmpty() || confirmEmailCad.isEmpty()) {
            Toast.makeText(this, "Preencha seu email", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!emailCad.equals(confirmEmailCad)) {
            Toast.makeText(this, "Emails não coincidem!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (senhaCad.isEmpty() || confirmPasswordCad.isEmpty()) {
            Toast.makeText(this, "Preencha sua senha", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!senhaCad.equals(confirmPasswordCad)) {
            Toast.makeText(this, "Senhas não coincidem!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ValidationUtils.validarEmail(emailCad)) {
            Toast.makeText(this, "Email inválido!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!ValidationUtils.validarSenha(senhaCad)) {
            Toast.makeText(this, "A senha deve ter no mínimo 6 caracteres, um número e um caractere especial!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Cria objeto usuário com os dados preenchidos
        Usuario usuario = new Usuario();
        usuario.setNome(nomeCad);
        usuario.setEmail(emailCad);
        usuario.setSenha(senhaCad);
        usuario.setTipo(verificaTipoUsuario()); // "P" para passageiro, "M" para motorista

        // Chama método para cadastrar no Firebase
        cadastarFirebase(usuario);
    }

    // Verifica se o usuário é passageiro (P) ou motorista (M)
    public String verificaTipoUsuario() {
        return switchCadastro.isChecked() ? "M" : "P";
    }

    // Realiza o cadastro no Firebase Authentication
    private void cadastarFirebase(Usuario usuario) {
        FirebaseAuth auth = FireBase.getFirebaseAuth();

        auth.createUserWithEmailAndPassword(usuario.getEmail(), usuario.getSenha())
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            try {
                                // Obtém UID do usuário
                                String uidUsuario = task.getResult().getUser().getUid();
                                usuario.setId(uidUsuario);
                                usuario.salvar(); // Salva no banco

                                // Atualiza o nome no perfil do Firebase
                                UsuarioFirebase.atualizarNomeUsuario(usuario.getNome());

                                // Redireciona para a tela de acordo com o tipo de usuário
                                if (Objects.equals(usuario.getTipo(), "P")) {
                                    String mensagem = "Sucesso ao cadastrar passageiro";
                                    startActivity(new Intent(CadastroActivity.this, PassageiroActivity.class));
                                    finish();
                                    Toast.makeText(CadastroActivity.this, mensagem, Toast.LENGTH_SHORT).show();
                                } else {
                                    String mensagem = "Sucesso ao cadastrar motorista";
                                    startActivity(new Intent(CadastroActivity.this, RequisicoesActivity.class));
                                    finish();
                                    Toast.makeText(CadastroActivity.this, mensagem, Toast.LENGTH_SHORT).show();
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        } else {
                            // Trata os possíveis erros de cadastro
                            String error = "";
                            try {
                                throw Objects.requireNonNull(task.getException());
                            } catch (FirebaseAuthWeakPasswordException e) {
                                error = "Digite uma senha mais forte!";
                            } catch (FirebaseAuthInvalidCredentialsException e) {
                                error = "Digite um E-mail válido!";
                            } catch (FirebaseAuthUserCollisionException e) {
                                error = "Conta já cadastrada!";
                            } catch (Exception e) {
                                error = "Erro ao cadastrar usuario: " + e.getMessage();
                                e.printStackTrace();
                            }
                            Toast.makeText(CadastroActivity.this, "Erro: " + error, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
