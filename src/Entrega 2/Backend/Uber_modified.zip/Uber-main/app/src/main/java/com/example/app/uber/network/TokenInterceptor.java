package com.example.app.uber.network;

import android.util.Log;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

import java.io.IOException;

public class TokenInterceptor implements Interceptor {

    private String token;

    // Construtor que recebe o token
    public TokenInterceptor(String token) {
        this.token = token;
    }

    @Override
    public Response intercept(Chain chain) throws IOException {

        // Cria um novo request com o cabeçalho de autorização
        Request newRequest = chain.request().newBuilder()
                .addHeader("Authorization", "Bearer " + token)
                .build();

        // Exibe o URL da requisição e o token no log
        Log.d("TokenInterceptor", "Requesting: " + newRequest.url());
        Log.d("TokenInterceptor", "Token: " + token);

        // Prossegue com a requisição
        return chain.proceed(newRequest);
    }

    // Método para atualizar o token
    public void setToken(String token) {
        this.token = token;
    }
}
