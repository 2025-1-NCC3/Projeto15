package com.example.app.uber.utils;

import android.os.Build;

import androidx.annotation.RequiresApi;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import java.util.Base64;

public class EncryptionUtil {
    // Algoritmo de criptografia com modo GCM e sem preenchimento
    private static final String ALGORITHM = "AES/GCM/NoPadding";

    // Gera uma chave secreta de 256 bits para uso no algoritmo AES
    public static SecretKey generateKey() throws Exception {
        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(256);  // Usa chave de 256 bits
        return keyGenerator.generateKey();
    }

    // Método para criptografar os dados
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static String encrypt(String data, SecretKey key) throws Exception {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, key);

        // Obtém o vetor de inicialização (IV)
        byte[] iv = cipher.getIV();

        // Criptografa os dados
        byte[] encryptedData = cipher.doFinal(data.getBytes());

        // Codifica os dados criptografados e o IV em Base64 e os junta com separador ":"
        String encodedEncryptedData = Base64.getEncoder().encodeToString(encryptedData);
        String encodedIv = Base64.getEncoder().encodeToString(iv);

        return encodedEncryptedData + ":" + encodedIv;
    }

    // Método para descriptografar os dados criptografados
    @RequiresApi(api = Build.VERSION_CODES.O)
    public static String decrypt(String encryptedData, String iv, SecretKey key) throws Exception {
        // Decodifica os dados criptografados e o IV de Base64 para bytes
        byte[] encryptedBytes = Base64.getDecoder().decode(encryptedData);
        byte[] ivBytes = Base64.getDecoder().decode(iv);

        // Configura o Cipher com o algoritmo e os parâmetros corretos
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        GCMParameterSpec spec = new GCMParameterSpec(128, ivBytes); // Especificação GCM com 128 bits de autenticação
        cipher.init(Cipher.DECRYPT_MODE, key, spec);

        // Descriptografa os dados
        byte[] decryptedData = cipher.doFinal(encryptedBytes);

        return new String(decryptedData); // Retorna os dados em forma de string
    }
}
