package com.example.app.uber.utils;


import android.content.Context;
import android.content.SharedPreferences;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import java.io.IOException;
import java.security.GeneralSecurityException;

/*
  Gerenciamento seguro de tokens usando EncryptedSharedPreferences
 */
public class TokenManager {

    private static final String PREFS_NAME = "tokens_criptografados";
    private static final String KEY_ACCESS = "access_token";
    private static final String KEY_REFRESH = "refresh_token";
    private static SharedPreferences sharedPreferences;

    /*
      Retorna o SharedPreferences criptografado, criando-o se necessário.
      @param context Contexto da aplicação.
      @return SharedPreferences criptografados.
     */
    private static SharedPreferences getPrefs(Context context) throws GeneralSecurityException, IOException {
        if (sharedPreferences == null) {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            sharedPreferences = EncryptedSharedPreferences.create(
                    context,
                    PREFS_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );
        }
        return sharedPreferences;
    }

    /*
      Salva os tokens de acesso e refresh.
      @param context Contexto da aplicação.
      @param accessToken O token de acesso.
      @param refreshToken O token de refresh.
     */
    public static void salvarTokens(Context context, String accessToken, String refreshToken) {
        try {
            SharedPreferences prefs = getPrefs(context);
            prefs.edit()
                    .putString(KEY_ACCESS, accessToken)
                    .putString(KEY_REFRESH, refreshToken)
                    .apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /*
      Obtém o token de acesso salvo.
      @param context Contexto da aplicação.
      @return O token de acesso, ou null se não encontrado.
     */
    public static String obterAccessToken(Context context) {
        try {
            return getPrefs(context).getString(KEY_ACCESS, null);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /*
      Obtém o token de refresh salvo.
      @param context Contexto da aplicação.
      @return O token de refresh, ou null se não encontrado.
     */
    public static String obterRefreshToken(Context context) {
        try {
            return getPrefs(context).getString(KEY_REFRESH, null);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    /*
      Remove os tokens armazenados.
      @param context Contexto da aplicação.
     */
    public static void removerTokens(Context context) {
        try {
            SharedPreferences prefs = getPrefs(context);
            prefs.edit()
                    .remove(KEY_ACCESS)
                    .remove(KEY_REFRESH)
                    .apply();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
