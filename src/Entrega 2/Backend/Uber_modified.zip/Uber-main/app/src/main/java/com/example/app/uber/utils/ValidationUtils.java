package com.example.app.uber.utils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUtils {

    // Expressão regular otimizada para validar formato de email
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
            "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );

    // Expressão regular para senha forte: mínimo 8 caracteres, pelo menos 1 número e 1 caractere especial
    private static final int MIN_PASSWORD_LENGTH = 8;  // Definindo o tamanho mínimo diretamente
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(
            "^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]{" + MIN_PASSWORD_LENGTH + ",}$"
    );

    public static boolean validarEmail(String email) {
        return email != null && EMAIL_PATTERN.matcher(email).matches();
    }

    public static boolean validarSenha(String senha) {
        return senha != null && PASSWORD_PATTERN.matcher(senha).matches();
    }
}

