package com.example.app.uber.network;

import okhttp3.Authenticator;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

public class RetrofitClient {

    private static volatile Retrofit retrofit = null;

    private RetrofitClient() { }

    public static Retrofit getRetrofitInstance(String token, String baseUrl) {
        if (retrofit == null) {
            synchronized (RetrofitClient.class) {
                if (retrofit == null) {
                    OkHttpClient client = new OkHttpClient.Builder()
                            .addInterceptor(new TokenInterceptor(token))
                            .connectTimeout(30, TimeUnit.SECONDS)
                            .readTimeout(30, TimeUnit.SECONDS)
                            .retryOnConnectionFailure(true)
                            .authenticator(new Authenticator() {
                                @Override
                                public Request authenticate(Route route, Response response) throws IOException {

                                    String newToken = refreshToken();
                                    return response.request().newBuilder()
                                            .header("Authorization", "Bearer " + newToken)
                                            .build();
                                }
                            })
                            .build();

                    retrofit = new Retrofit.Builder()
                            .baseUrl(baseUrl)  // Using the provided base URL instead of Constants.BASE_URL
                            .client(client)
                            .addConverterFactory(GsonConverterFactory.create())
                            .build();
                }
            }
        }
        return retrofit;
    }

    public static void resetInstance() {
        synchronized (RetrofitClient.class) {
            retrofit = null;
        }
    }

    private static String refreshToken() {
        return "new_refreshed_token";
    }
}
